#실행방법
1.

    ./build.sh

#빌드 가능한 롬
① CyanogenMod ② CyanogenOS ③ ResurrectionRemix ④ Temasek ⑤ AICP ⑥ CroidAndroid ⑦ NamelessROM ⑧ XOSP ⑨ Haxynox ⓞ OmniROM

i9300/i9305 모델은 AICP,CroidAndroid,NamelessROM,XOSP,Haxynox,OmniROM 빌드를 지원하지 않습니다.

#빌드 가능한 기종
① SHV-E210S ② SHV-E210K ③ SHV-E210L ④ GT-I9300 ⑤ GT-I9305 
